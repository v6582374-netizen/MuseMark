(()=>{const g="__autonote_content_ready__",v=window;if(v[g])return;v[g]=!0;let a=null,l="",b="",d="",p=new Set,u=!1;chrome.runtime.onMessage.addListener((t,o,n)=>{if(!t||t.protocolVersion!==1)return!1;if(t.type==="autonote/startCapture"){const e=t.payload;return l=e.sessionId,d="",p=new Set,u=!1,S("Captured. AI is analyzing..."),(async()=>{const r=await O(e.sessionId,e.maxChars);n(r)})(),!0}if(t.type==="autonote/bookmarkLinked"){const e=t.payload;return e.sessionId===l&&(b=e.bookmarkId),!1}if(t.type==="autonote/stage1Ready"){const e=t.payload;return e.sessionId===l&&L(e.summary,e.suggestedCategoryCandidates,e.suggestedTags,e.textTruncated),!1}if(t.type==="autonote/classifyPending")return t.payload.sessionId===l&&a&&(a.status.textContent="Classifying and saving..."),!1;if(t.type==="autonote/stageError"){const e=t.payload;return e.sessionId===l&&a&&(u=!1,a.status.textContent="Saved to Inbox with AI error",a.summary.textContent=e.error),!1}if(t.type==="autonote/finalized"){const e=t.payload;if(e.sessionId===l&&a){u=!1;const r=e.category||"Uncategorized",i=(e.tags??[]).join(", ");a.status.textContent=`Saved: ${r}${i?` | ${i}`:""}`,a.summary.textContent="Done. Auto closing...",window.setTimeout(()=>w(),1200)}return!1}return!1}),document.addEventListener("keydown",t=>{t.key==="Escape"&&a?.root.style.display!=="none"&&w()});function h(){if(a)return a;const t=document.createElement("div");t.id="autonote-overlay",t.innerHTML=`
      <div class="autonote-card">
        <div class="autonote-title">AutoNote</div>
        <div class="autonote-status"></div>
        <div class="autonote-summary"></div>
        <div class="autonote-section">
          <div class="autonote-label">Category candidates</div>
          <div class="autonote-category-box"></div>
        </div>
        <div class="autonote-section">
          <div class="autonote-label">Tag candidates</div>
          <div class="autonote-tag-box"></div>
        </div>
        <input class="autonote-input" type="text" maxlength="200" placeholder="One-line note (optional). Press Enter to save..." />
        <div class="autonote-hint">Enter = save now, Esc = close (keeps bookmark in Inbox)</div>
        <div class="autonote-actions">
          <button class="autonote-manager">Open Library</button>
        </div>
      </div>
    `;const o=document.createElement("style");o.textContent=`
      #autonote-overlay {
        position: fixed;
        right: 18px;
        bottom: 18px;
        z-index: 2147483647;
        width: min(430px, calc(100vw - 28px));
        font-family: "Avenir Next", "SF Pro Display", "Noto Sans SC", sans-serif;
      }
      #autonote-overlay .autonote-card {
        border-radius: 16px;
        background: linear-gradient(135deg, #101a34 0%, #1d2746 48%, #1f385f 100%);
        color: #f4f8ff;
        border: 1px solid rgba(214, 224, 255, 0.28);
        box-shadow: 0 22px 52px rgba(5, 10, 25, 0.42);
        padding: 14px 14px 12px;
        backdrop-filter: blur(8px);
        animation: autonote-enter 170ms ease-out;
      }
      #autonote-overlay .autonote-title {
        font-weight: 750;
        letter-spacing: 0.2px;
        font-size: 15px;
        margin-bottom: 8px;
      }
      #autonote-overlay .autonote-status {
        font-size: 13px;
        color: #d3e2ff;
      }
      #autonote-overlay .autonote-summary {
        margin-top: 8px;
        font-size: 12px;
        line-height: 1.45;
        color: #d8e6ff;
        max-height: 88px;
        overflow: auto;
        white-space: pre-wrap;
      }
      #autonote-overlay .autonote-section {
        margin-top: 10px;
      }
      #autonote-overlay .autonote-label {
        font-size: 11px;
        color: #a8c5ff;
        margin-bottom: 6px;
      }
      #autonote-overlay .autonote-category-box,
      #autonote-overlay .autonote-tag-box {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
      }
      #autonote-overlay .autonote-chip {
        border: 1px solid rgba(190, 212, 255, 0.4);
        background: rgba(23, 46, 79, 0.72);
        color: #eff6ff;
        border-radius: 999px;
        font-size: 11px;
        padding: 4px 9px;
        cursor: pointer;
      }
      #autonote-overlay .autonote-chip.active {
        background: #8bd1ff;
        border-color: #8bd1ff;
        color: #07203a;
      }
      #autonote-overlay .autonote-input {
        width: 100%;
        margin-top: 12px;
        border-radius: 10px;
        border: 1px solid rgba(187, 208, 255, 0.5);
        background: rgba(9, 20, 38, 0.65);
        color: #f3f8ff;
        padding: 9px 10px;
        font-size: 13px;
        outline: none;
      }
      #autonote-overlay .autonote-input:focus {
        border-color: #9bc8ff;
        box-shadow: 0 0 0 2px rgba(123, 188, 255, 0.26);
      }
      #autonote-overlay .autonote-hint {
        margin-top: 8px;
        font-size: 11px;
        color: #b8d1ff;
      }
      #autonote-overlay .autonote-actions {
        margin-top: 10px;
        display: flex;
        justify-content: flex-end;
      }
      #autonote-overlay .autonote-manager {
        border: none;
        border-radius: 10px;
        background: #86d4ff;
        color: #072039;
        font-weight: 650;
        padding: 7px 10px;
        cursor: pointer;
        font-size: 12px;
      }
      @keyframes autonote-enter {
        from {
          transform: translateY(8px);
          opacity: 0;
        }
        to {
          transform: translateY(0);
          opacity: 1;
        }
      }
    `;const n=t.querySelector(".autonote-status"),e=t.querySelector(".autonote-summary"),r=t.querySelector(".autonote-input"),i=t.querySelector(".autonote-category-box"),c=t.querySelector(".autonote-tag-box"),y=t.querySelector(".autonote-hint"),s=t.querySelector(".autonote-manager");return r.addEventListener("keydown",f=>{f.key==="Enter"&&!f.shiftKey&&(f.preventDefault(),T())}),s.addEventListener("click",()=>{chrome.runtime.sendMessage({protocolVersion:1,type:"content/openManager",payload:{}})}),t.style.display="none",document.documentElement.appendChild(o),document.documentElement.appendChild(t),a={root:t,status:n,summary:e,noteInput:r,categoryBox:i,tagBox:c,saveHint:y},a}function S(t){const o=h();o.root.style.display="block",o.status.textContent=t,o.summary.textContent="",o.noteInput.value="",o.saveHint.textContent="Enter = save now, Esc = close (keeps bookmark in Inbox)",o.categoryBox.innerHTML="",o.tagBox.innerHTML="",o.noteInput.focus()}function w(){a&&(a.root.style.display="none")}function L(t,o,n,e){const r=h();r.status.textContent="AI analyzed page. Add a note and press Enter.",r.summary.textContent=e?`${t}

Text was truncated due to max character limit.`:t,r.noteInput.focus(),E(o),I(n)}function E(t){if(a){a.categoryBox.innerHTML="";for(const o of t.slice(0,6)){const n=C(o);if(!n)continue;const e=document.createElement("button");e.type="button",e.className="autonote-chip",e.textContent=n,e.addEventListener("click",()=>{d=d===n?"":n,(a?.categoryBox.querySelectorAll(".autonote-chip")??[]).forEach(i=>i.classList.remove("active")),d===n&&e.classList.add("active")}),a.categoryBox.appendChild(e)}}}function I(t){if(a){a.tagBox.innerHTML="";for(const o of t.slice(0,12)){const n=C(o);if(!n)continue;const e=document.createElement("button");e.type="button",e.className="autonote-chip",e.textContent=n,e.addEventListener("click",()=>{p.has(n)?(p.delete(n),e.classList.remove("active")):(p.add(n),e.classList.add("active"))}),a.tagBox.appendChild(e)}}}async function T(){if(!(!a||u||!l)){u=!0,a.status.textContent="Saving...";try{await chrome.runtime.sendMessage({protocolVersion:1,type:"content/submitNote",payload:{sessionId:l,bookmarkId:b||void 0,note:a.noteInput.value,selectedCategory:d||void 0,selectedTags:Array.from(p)}})}catch(t){u=!1,a.status.textContent="Save failed",a.summary.textContent=q(t)}}}async function O(t,o){const n=document.title||location.hostname,r=document.querySelector("link[rel='canonical']")?.href||void 0,i=z(),c=window.getSelection()?.toString().trim()??"",s=document.querySelector("article, main")?.textContent?.trim()??"",f=document.body?.innerText?.trim()??"",x=s||f,R=c&&!x?"selection_only":s?"readability":"dom_text",H=c?`${c}

${x}`:x,m=B(H),U=m.length>o,k=m.slice(0,o),$=await M(k||`${location.href}|${n}`);return{sessionId:t,url:location.href,canonicalUrl:r,title:n,domain:location.hostname,favIconUrl:i,selection:c,text:k,textDigest:$,textChars:m.length,captureMode:R,wasTruncated:U}}function z(){const t=Array.from(document.querySelectorAll("link[rel*='icon'], link[rel='apple-touch-icon']"));let o="",n=-1;for(const e of t){const r=N(e.getAttribute("href"));if(!r||r.startsWith("data:"))continue;const i=(e.rel||"").toLowerCase(),c=(e.type||"").toLowerCase();let s=A(e.sizes?.value);i.includes("icon")&&(s+=40),i.includes("shortcut")&&(s+=12),i.includes("apple-touch-icon")&&(s+=20),c.includes("svg")&&(s+=18),r.includes("favicon")&&(s+=8),s>n&&(n=s,o=r)}if(o)return o;try{return new URL("/favicon.ico",location.origin).toString()}catch{return}}function A(t){const o=(t??"").trim().toLowerCase();if(!o||o==="any")return 24;let n=0;for(const e of o.split(/\s+/)){const r=e.match(/^(\d+)x(\d+)$/);if(!r)continue;const i=Number(r[1]),c=Number(r[2]);!Number.isFinite(i)||!Number.isFinite(c)||(n=Math.max(n,Math.min(i,c)))}return n<=0?8:Math.min(96,n)}function N(t){const o=(t??"").trim();if(!o)return"";try{return new URL(o,location.href).toString()}catch{return""}}async function M(t){try{const o=new TextEncoder().encode(t),n=await crypto.subtle.digest("SHA-256",o);return Array.from(new Uint8Array(n)).map(r=>r.toString(16).padStart(2,"0")).join("")}catch{return _(t)}}function _(t){let o=0;for(let n=0;n<t.length;n+=1)o=(o<<5)-o+t.charCodeAt(n),o|=0;return`fallback_${Math.abs(o)}`}function B(t){return t.replace(/\r/g,`
`).replace(/[ \t]+/g," ").replace(/\n{3,}/g,`

`).trim()}function C(t){return t.trim().replace(/\s+/g," ").slice(0,40)}function q(t){return t instanceof Error?t.message:String(t??"Unknown error")}})();
//# sourceMappingURL=content.js.map
